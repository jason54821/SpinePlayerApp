using Spine.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ButtonManager : MonoBehaviour
{

    [SerializeField] private Button foreplayA;
    [SerializeField] private Button actionsA;
    [SerializeField] private Button shootA;
    [SerializeField] private Button afterplayA;
    [SerializeField] private Button close;

    [SerializeField] private Button foreplayB;
    [SerializeField] private Button actionsB;
    [SerializeField] private Button shootB;
    [SerializeField] private Button afterplayB;
    [SerializeField] private Button open;

    [SerializeField] private Button hide;
    [SerializeField] private Button auto;
    [SerializeField] private Button menu;

    [SerializeField] private GameObject viewA;
    [SerializeField] private GameObject viewB;

    [SerializeField] private GameObject[] AStatusLampOn;
    [SerializeField] private GameObject[] BStatusLampOn;
    [SerializeField] private GameObject[] AStatusLampOff;
    [SerializeField] private GameObject[] BStatusLampOff;

    [SerializeField] private GameObject[] AStatusLampOnc;
    [SerializeField] private GameObject[] BStatusLampOnc;
    [SerializeField] private GameObject[] AStatusLampOffc;
    [SerializeField] private GameObject[] BStatusLampOffc;

    [SerializeField] private CanvasGroup iconsGroup;

    AnimationManager spineBase;

    public StatusIndex AStatus;
    public StatusIndex BStatus;

    [SerializeField] private int aIndex = 2;
    [SerializeField] private int bIndex = 3;

    [SerializeField] private bool isMenuOpen = true;


    // Start is called before the first frame update
    void Awake()
    {
        GameObject obj = GameObject.Find("SpineBase");
        spineBase = obj.GetComponent<AnimationManager>();
        foreplayA.onClick.AddListener(OnClickA);
        actionsA.onClick.AddListener(OnClickB);
        shootA.onClick.AddListener(OnClickC);
        afterplayA.onClick.AddListener(OnClickD);
        foreplayB.onClick.AddListener(OnClickA);
        actionsB.onClick.AddListener(OnClickB);
        shootB.onClick.AddListener(OnClickC);
        afterplayB.onClick.AddListener(OnClickD);

        open.onClick.AddListener(OpenMenu);
        close.onClick.AddListener(CloseMenu);

        hide.onClick.AddListener(HideUI);
        auto.onClick.AddListener(Auto);
        menu.onClick.AddListener(ReturnMenu);


        AStatus.SetValue(0);
        BStatus.SetValue(0);
    }

    void Update()
    {

        if (Input.GetMouseButtonDown(0))
        {
            Debug.Log("Screen clicked!");
            iconsGroup.alpha = 1;
        }

        if (isMenuOpen)
        {
            switch (spineBase.playingAnimation)
            {
                case AnimationManager.AnimationStateFlag.A1:
                    ResetLamp();
                    AStatusLampOff[0].SetActive(false);
                    AStatusLampOn[0].SetActive(true);
                    break;

                case AnimationManager.AnimationStateFlag.A2:
                    ResetLamp();
                    AStatusLampOff[1].SetActive(false);
                    AStatusLampOn[1].SetActive(true);
                    break;

                case AnimationManager.AnimationStateFlag.B1:
                    ResetLamp();
                    BStatusLampOff[0].SetActive(false);
                    BStatusLampOn[0].SetActive(true);
                    break;

                case AnimationManager.AnimationStateFlag.B2:
                    ResetLamp();
                    BStatusLampOff[1].SetActive(false);
                    BStatusLampOn[1].SetActive(true);
                    break;

                case AnimationManager.AnimationStateFlag.B3:
                    ResetLamp();
                    BStatusLampOff[2].SetActive(false);
                    BStatusLampOn[2].SetActive(true);
                    break;

                //case AnimationManager.AnimationStateFlag.B4:
                //    ResetLamp();
                //    BStatusLampOff[3].SetActive(false);
                //    BStatusLampOn[3].SetActive(true);
                //    break;

                default:
                    break;
            }
        }
        else
        {
            switch (spineBase.playingAnimation)
            {
                case AnimationManager.AnimationStateFlag.A1:
                    ResetLamp();
                    AStatusLampOffc[0].SetActive(false);
                    AStatusLampOnc[0].SetActive(true);
                    break;

                case AnimationManager.AnimationStateFlag.A2:
                    ResetLamp();
                    AStatusLampOffc[1].SetActive(false);
                    AStatusLampOnc[1].SetActive(true);
                    break;

                case AnimationManager.AnimationStateFlag.B1:
                    ResetLamp();
                    BStatusLampOffc[0].SetActive(false);
                    BStatusLampOnc[0].SetActive(true);
                    break;

                case AnimationManager.AnimationStateFlag.B2:
                    ResetLamp();
                    BStatusLampOffc[1].SetActive(false);
                    BStatusLampOnc[1].SetActive(true);
                    break;

                case AnimationManager.AnimationStateFlag.B3:
                    ResetLamp();
                    BStatusLampOffc[2].SetActive(false);
                    BStatusLampOnc[2].SetActive(true);
                    break;

                //case AnimationManager.AnimationStateFlag.B4:
                //    ResetLamp();
                //    BStatusLampOffc[3].SetActive(false);
                //    BStatusLampOnc[3].SetActive(true);
                //    break;

                default:
                    break;
            }
        }

    }

    private void ResetLamp()
    {
        if (isMenuOpen)
        {
            AStatusLampOn[0].SetActive(false);
            AStatusLampOn[1].SetActive(false);
            BStatusLampOn[0].SetActive(false);
            BStatusLampOn[1].SetActive(false);
            BStatusLampOn[2].SetActive(false);
            //BStatusLampOn[3].SetActive(false);

            AStatusLampOff[0].SetActive(true);
            AStatusLampOff[1].SetActive(true);
            BStatusLampOff[0].SetActive(true);
            BStatusLampOff[1].SetActive(true);
            BStatusLampOff[2].SetActive(true);
            //BStatusLampOff[3].SetActive(true);
        }
        else
        {
            AStatusLampOnc[0].SetActive(false);
            AStatusLampOnc[1].SetActive(false);
            BStatusLampOnc[0].SetActive(false);
            BStatusLampOnc[1].SetActive(false);
            BStatusLampOnc[2].SetActive(false);
            //BStatusLampOnc[3].SetActive(false);

            AStatusLampOffc[0].SetActive(true);
            AStatusLampOffc[1].SetActive(true);
            BStatusLampOffc[0].SetActive(true);
            BStatusLampOffc[1].SetActive(true);
            BStatusLampOffc[2].SetActive(true);
            //BStatusLampOffc[3].SetActive(true);
        }
    }

    private void ResetStatus()
    {
        AStatus.SetValue(0);
        BStatus.SetValue(0);
    }

    void OnClickA()
    {
        EventSystem.current.SetSelectedGameObject(null);

        if (spineBase.playingAnimation >= (AnimationManager.AnimationStateFlag)3)
        {
            ResetStatus();
        }

        for (int i = 0; i <= aIndex; i++)
        {
            if(AStatus.GetValue() == i)
            {
                AStatus.ApplyChange(1);
                i++;
                spineBase.PlayA(i);
                Debug.Log("OnClickA > A:" + i);

                if (AStatus.GetValue() >= aIndex)
                {
                    AStatus.SetValue(0);
                }
                break;
            }
        }
    }

    void OnClickB()
    {
        EventSystem.current.SetSelectedGameObject(null);

        if (spineBase.playingAnimation < (AnimationManager.AnimationStateFlag)3 || spineBase.playingAnimation >= (AnimationManager.AnimationStateFlag)7)
        {
            ResetStatus();
        }

        for (int i = 0; i <= bIndex; i++)
        {
            if (BStatus.GetValue() == i)
            {
                BStatus.ApplyChange(1);
                i++;
                spineBase.PlayB(i);
                Debug.Log("OnClickB > B:" + i);

                if (BStatus.GetValue() >= bIndex)
                {
                    BStatus.SetValue(0);
                }
                break;
            }
        }
    }

    void OnClickC()
    {
        spineBase.PlayC();
    }

    void OnClickD()
    {
        spineBase.PlayD();
    }

    void OpenMenu()
    {
        isMenuOpen = true;
        viewB.SetActive(false);
        viewA.SetActive(true);
    }

    void CloseMenu()
    {
        isMenuOpen = false;
        viewA.SetActive(false);
        viewB.SetActive(true);
    }

    void HideUI()
    {
        iconsGroup.alpha = 0;
    }

    void Auto()
    {
        spineBase.PlayMix();
    }

    void ReturnMenu()
    {
        SceneManager.LoadScene("Menu");
    }
}
