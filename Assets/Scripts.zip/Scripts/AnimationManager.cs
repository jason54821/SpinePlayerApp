using Spine;
using Spine.Unity;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using static UnityEngine.EventSystems.EventTrigger;

public class AnimationManager : MonoBehaviour
{

    
    [SpineAnimation] public string A1;
    [SpineAnimation] public string A1_mouth;
    [SpineAnimation] public string A2;
    [SpineAnimation] public string A2_mouth;

    [SpineAnimation] public string B1;
    [SpineAnimation] public string B1_mouth;
    [SpineAnimation] public string B2;
    [SpineAnimation] public string B2_mouth;
    [SpineAnimation] public string B3;
    [SpineAnimation] public string B3_mouth;
    [SpineAnimation] public string B4;
    [SpineAnimation] public string B4_mouth;

    [SpineAnimation] public string C1;
    [SpineAnimation] public string C1_mouth;

    [SpineAnimation] public string D1;
    [SpineAnimation] public string D1_mouth;

    [SpineAnimation] public string Mix;



    SkeletonAnimation skeletonAnimation;
    public Spine.AnimationState animationState;
    public Spine.Skeleton skeleton;

    public StatusIndex AStatus;
    public StatusIndex BStatus;

    [SerializeField] SoundManager soundManager;
    [SerializeField] SoundManager trackingSoundManager;


    [SerializeField] AudioSource trackingAudioSource;

    public enum AnimationStateFlag
    {
        None,
        A1,
        A2,
        B1,
        B2,
        B3,
        B4,
        C1,
        D1,
        Mix
    }

    public AnimationStateFlag playingAnimation = AnimationStateFlag.None;

    void Start()
    {
        trackingAudioSource = trackingSoundManager.GetComponent<AudioSource>();
        skeletonAnimation = GetComponent<SkeletonAnimation>();
        animationState = skeletonAnimation.AnimationState;
        skeleton = skeletonAnimation.Skeleton;

        PlayA(1);
        AStatus.SetValue(1);
    }

    void Update()
    {
        
    }

    public void PlayA(int seq)
    {
        switch (seq)
        {
            case 1:
                playingAnimation = AnimationStateFlag.A1;
                PlaySoundSeq("A1");
                animationState.SetAnimation(0, A1, true);
                animationState.SetAnimation(1, A1_mouth, false);
                break;
            case 2:
                playingAnimation = AnimationStateFlag.A2;
                PlaySoundSeq("A2");
                animationState.SetAnimation(0, A2, true);
                animationState.SetAnimation(1, A2_mouth, false);
                break;
        }
    }

    public void PlayB(int seq)
    {
        switch (seq)
        {
            case 1:
                playingAnimation = AnimationStateFlag.B1;
                PlaySoundSeq("B1");
                animationState.SetAnimation(0, B1, true);
                animationState.SetAnimation(1, B1_mouth, false);
                break;
            case 2:
                playingAnimation = AnimationStateFlag.B2;
                PlaySoundSeq("B2");
                animationState.SetAnimation(0, B2, true);
                animationState.SetAnimation(1, B2_mouth, false);
                break;
            case 3:
                playingAnimation = AnimationStateFlag.B3;
                PlaySoundSeq("B3");
                animationState.SetAnimation(0, B3, true);
                animationState.SetAnimation(1, B3_mouth, false);
                break;
            case 4:
                playingAnimation = AnimationStateFlag.B4;
                PlaySoundSeq("B4");
                animationState.SetAnimation(0, B4, true);
                animationState.SetAnimation(1, B4_mouth, false);
                break;
        }
    }

    public void PlayC()
    {
        playingAnimation = AnimationStateFlag.C1;
        PlaySoundSeq("C1");
        TrackEntry C1Entry = animationState.SetAnimation(0, C1, false);
        animationState.SetAnimation(1, C1_mouth, false);

        C1Entry.Complete += OnC1PlayComplete;
    }
        private void OnC1PlayComplete(TrackEntry C1Entry)
        {
            TrackEntry C2Entry = animationState.SetAnimation(0, C1, false);
            C2Entry.Complete += OnC2PlayComplete;
    }

        private void OnC2PlayComplete(TrackEntry C2Entry)
        {
            PlayD();
        }

    public void PlayD()
    {
        playingAnimation = AnimationStateFlag.D1;
        PlaySoundSeq("D1");
        animationState.SetAnimation(0, D1, true);
        animationState.SetAnimation(1, D1_mouth, false);
        //IdleDiaEntry.Complete += OnIdleDiaComplete;
    }

    public void PlayMix()
    {
        playingAnimation = AnimationStateFlag.Mix;
        TrackEntry MixEntry = animationState.SetAnimation(0, Mix, false);
        PlaySoundSeq("Mix");
        MixEntry.Complete += OnMixPlayComplete;
    }
        private void OnMixPlayComplete(TrackEntry MixEntry)
        {
            PlayD();
        }


    private void PlaySoundSeq(string name)
    {
        StopAll();

        switch (name)
        {
            case "A1":
                soundManager.Play("A1se");
                trackingSoundManager.Play("A1dia");
                StartCoroutine(CheckingAnimation(trackingAudioSource, AnimationStateFlag.A1, () => {
                    Debug.Log("A1loop");
                    soundManager.Play("A1loop");
                }));
                break;

            case "A2":
                soundManager.Play("A2se");
                trackingSoundManager.Play("A2dia");
                StartCoroutine(CheckingAnimation(trackingAudioSource, AnimationStateFlag.A2, () => {
                    Debug.Log("A2loop");
                    soundManager.Play("A2loop");
                }));
                break;

            case "B1":
                soundManager.Play("B1se");
                trackingSoundManager.Play("B1dia");
                StartCoroutine(CheckingAnimation(trackingAudioSource, AnimationStateFlag.B1, () => {
                    Debug.Log("B1loop");
                    soundManager.Play("B1loop");
                }));
                break;

            case "B2":
                soundManager.Play("B2se");
                trackingSoundManager.Play("B2dia");
                StartCoroutine(CheckingAnimation(trackingAudioSource, AnimationStateFlag.B2, () => {
                    Debug.Log("B2loop");
                    soundManager.Play("B2loop");
                }));
                break;

            case "B3":
                soundManager.Play("B3se");
                trackingSoundManager.Play("B3dia");
                StartCoroutine(CheckingAnimation(trackingAudioSource, AnimationStateFlag.B3, () => {
                    Debug.Log("B3loop");
                    soundManager.Play("B3loop");
                }));
                break;

            case "B4":
                soundManager.Play("B4se");
                trackingSoundManager.Play("B4dia");
                StartCoroutine(CheckingAnimation(trackingAudioSource, AnimationStateFlag.B4, () => {
                    Debug.Log("B4loop");
                    soundManager.Play("B4loop");
                }));
                break;

            case "C1":
                trackingSoundManager.Play("C1all");
                break;

            case "D1":
                soundManager.Play("D1se1");
                trackingSoundManager.Play("D1dia");
                StartCoroutine(CheckingAnimation(trackingAudioSource, AnimationStateFlag.D1, () => {
                    Debug.Log("D1loop");
                    soundManager.Play("D1loop");
                }));
                break;

            case "Mix":
                soundManager.Play("Mix");
                break;
        }
    }

    private IEnumerator CheckingAnimation(AudioSource audio, AnimationStateFlag animationStateFlag, UnityAction callback)
    {
        while (true)
        {
            yield return new WaitForFixedUpdate();

            // �w�肳�ꂽ�A�j���[�V�����ƈ�v���Ă��Ȃ��ꍇ�͏I��
            if (playingAnimation != animationStateFlag)
            {
                break;
            }

            // �I�[�f�B�I���Đ�����Ă��Ȃ��ꍇ�ɃR�[���o�b�N�����s
            if (!audio.isPlaying)
            {
                callback();
                break;
            }
        }
    }

    private void StopAll()
    {
        soundManager.Stop();
        trackingSoundManager.Stop();
    }

}
