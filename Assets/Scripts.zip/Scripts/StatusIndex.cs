using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class StatusIndex : ScriptableObject
{

    public int Value;

    public void SetValue(int value)
    {
        Value = value;
    }

    public void SetValue(StatusIndex value)
    {
        Value = value.Value;
    }

    public void ApplyChange(int amount)
    {
        Value += amount;
    }

    public void ApplyChange(StatusIndex amount)
    {
        Value += amount.Value;
    }

    public int GetValue()
    {
        return Value;
    }
    
}
