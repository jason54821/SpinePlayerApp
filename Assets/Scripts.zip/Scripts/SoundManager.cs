using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    [SerializeField]
    public bool notDestory;

    [SerializeField]
    private int audioSourceNum = 1;

    [System.Serializable]
    public class SoundData
    {
        public string name;
        public AudioClip audioClip;
        public bool loopSw;
    }
 
    [SerializeField]
    private SoundData[] soundDatas;

    //AudioSource（スピーカー）を同時に鳴らしたい音の数だけ用意
    private AudioSource[] audioSourceList;
 
    //別名(name)をキーとした管理用Dictionary
    private Dictionary<string, SoundData> soundDictionary = new Dictionary<string, SoundData>();
 
    private void Awake()
    {

        if (notDestory == true)
        {
            DontDestroyOnLoad(this);
        }

        audioSourceList = new AudioSource[audioSourceNum];


        //auidioSourceList配列の数だけAudioSourceを自分自身に生成して配列に格納
        for (var i = 0; i < audioSourceList.Length; ++i)
        {
            audioSourceList[i] = gameObject.AddComponent<AudioSource>();
        }
 
        //soundDictionaryにセット
        foreach (var soundData in soundDatas)
        {
            soundDictionary.Add(soundData.name, soundData);
        }
    }
 
    //未使用のAudioSourceの取得 全て使用中の場合はnullを返却
    private AudioSource GetUnusedAudioSource()
    {
        for (var i = 0; i < audioSourceList.Length; ++i)
        {
            if (audioSourceList[i].isPlaying == false) return audioSourceList[i];
        }
 
        return null; //未使用のAudioSourceは見つかりませんでした
    }
 
    //指定されたAudioClipを未使用のAudioSourceで再生
    public void Play(AudioClip clip, bool loop)
    {
        var audioSource = GetUnusedAudioSource();
        if (audioSource == null) return; //再生できませんでした
        audioSource.clip = clip;
        audioSource.loop = loop;
        audioSource.Play();
    }

    public void Stop()
    {
        for (var i = 0; i < audioSourceList.Length; ++i)
        {
            if (audioSourceList[i].isPlaying == true) {
                audioSourceList[i].Stop();
            }
        }
    }

    // public void Stop(AudioClip clip)
    // {
    //     var audioSource = GetUnusedAudioSource();
    //     if (audioSource == null) return; //再生できませんでした
    //     audioSource.clip = clip;
    //     audioSource.Stop();
    // }
 
    //指定された別名で登録されたAudioClipを再生
    public void Play(string name)
    {
        if (soundDictionary.TryGetValue(name, out var soundData)) //管理用Dictionary から、別名で探索
        {
            Play(soundData.audioClip, soundData.loopSw); //見つかったら、再生
        }
        else
        {
            Debug.LogWarning($"その別名は登録されていません:{name}");
        }
    }

}
